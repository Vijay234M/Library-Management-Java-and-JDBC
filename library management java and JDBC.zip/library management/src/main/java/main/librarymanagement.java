package main;

import java.util.Scanner;
import model.customer;
import model.staff;
import service.manager;
import service.staffs;
import service.customers;
import services.libraryservices;

public class librarymanagement {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        libraryservices services = new libraryservices();

        while (true) {
            System.out.println("\n1. Manager\n2. Staff\n3. Customer\n4. Exit");
            System.out.print("Choice: ");
            int choice = scan.nextInt();

            switch (choice) {

            case 1:
                System.out.print("Manager username: ");
                String m = scan.next();
                System.out.print("Password: ");
                int mp = scan.nextInt();

                if (m.equals("manager") && mp == 1234)
                    new manager();
                else
                    System.out.println("Invalid Manager Login");
                break;

            case 2:
                System.out.print("Staff name: ");
                String s = scan.next();
                System.out.print("Password: ");
                int sp = scan.nextInt();

                staff st = services.staffLogin(s, sp);
                if (st != null) {
                    System.out.println("Welcome " + st.getStaffName());
                    new staffs();
                } else
                    System.out.println("Invalid Staff Login");
                break;

            case 3:
                System.out.print("Customer name: ");
                String c = scan.next();
                System.out.print("Password: ");
                int cp = scan.nextInt();

                customer cu = services.customerLogin(c, cp);
                if (cu != null) {
                    System.out.println("Welcome " + cu.getCustomerName());
                    new customers();
                } else
                    System.out.println("Invalid Customer Login");
                break;

            case 4:
                System.out.println("Thank You!");
                System.exit(0);
            }
        }
    }
}
