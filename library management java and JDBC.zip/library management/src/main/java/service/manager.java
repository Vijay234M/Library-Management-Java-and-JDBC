package service;

import java.util.Scanner;
import services.libraryservices;

public class manager {

    private Scanner scan = new Scanner(System.in);
    private libraryservices services = new libraryservices();

    public manager() {

        while (true) {
            System.out.println("\n========== MANAGER MENU ==========");
            System.out.println("1. Add Book");
            System.out.println("2. View Books");
            System.out.println("3. Search Book");
            System.out.println("4. Delete Book");
            System.out.println("5. View Issued Books");
            System.out.println("6. Logout");
            System.out.print("Enter choice: ");

            int choice = scan.nextInt();

            switch (choice) {

            case 1:
                System.out.print("Book Name: ");
                String name = scan.next();
                System.out.print("Book No: ");
                int no = scan.nextInt();
                System.out.print("Department: ");
                String dept = scan.next();
                System.out.print("Author: ");
                String author = scan.next();

                services.addbook(name, no, dept, author);
                break;

            case 2:
                services.viewbook();
                break;

            case 3:
                System.out.print("Enter Book ID: ");
                services.searchbook(scan.nextInt());
                break;

            case 4:
                System.out.print("Enter Book ID to delete: ");
                services.deletebook(scan.nextInt());
                break;

            case 5:
                services.viewIssuedBooks();
                break;

            case 6:
                System.out.println("Logged out successfully");
                return;

            default:
                System.out.println("Invalid choice");
            }
        }
    }
}
