package service;

import java.util.Scanner;
import services.libraryservices;

public class customers {

    private Scanner scan = new Scanner(System.in);
    private libraryservices services = new libraryservices();

    public customers() {

        while (true) {
            System.out.println("\n========== CUSTOMER MENU ==========");
            System.out.println("1. View Books");
            System.out.println("2. Search Book");
            System.out.println("3. Issue Book");
            System.out.println("4. Return Book");
            System.out.println("5. Logout");
            System.out.print("Enter choice: ");

            int choice = scan.nextInt();

            switch (choice) {

            case 1:
                services.viewbook();
                break;

            case 2:
                System.out.print("Enter Book ID: ");
                services.searchbook(scan.nextInt());
                break;

            case 3:
                System.out.print("Enter Book ID: ");
                int bid = scan.nextInt();
                System.out.print("Enter Your Name: ");
                String cname = scan.next();

                services.issueBook(bid, cname);
                break;

            case 4:
                System.out.print("Enter Book ID: ");
                services.returnBook(scan.nextInt());
                break;

            case 5:
                System.out.println("Logged out successfully");
                return;

            default:
                System.out.println("Invalid choice");
            }
        }
    }
}
