package services;

import java.sql.*;
import java.time.LocalDate;
import model.staff;
import model.customer;

public class libraryservices {

    public staff staffLogin(String name, int pass) {
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM staff WHERE staff_name=? AND password=?"
            );
            ps.setString(1, name);
            ps.setInt(2, pass);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new staff(rs.getInt("staff_id"), rs.getString("staff_name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public customer customerLogin(String name, int pass) {
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM customer WHERE customer_name=? AND password=?"
            );
            ps.setString(1, name);
            ps.setInt(2, pass);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new customer(rs.getInt("customer_id"), rs.getString("customer_name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void addbook(String name, int no, String dept, String author) {
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO books(name, book_no, department, author) VALUES (?,?,?,?)"
            );
            ps.setString(1, name);
            ps.setInt(2, no);
            ps.setString(3, dept);
            ps.setString(4, author);
            ps.executeUpdate();
            System.out.println("Book Added Successfully");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void viewbook() {
        try (Connection con = DBConnection.getConnection()) {
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM books");
            while (rs.next()) {
                System.out.println(
                    rs.getInt("id") + " | " +
                    rs.getString("name") + " | " +
                    rs.getString("author") + " | " +
                    rs.getString("status")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void searchbook(int id) {
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM books WHERE id=?"
            );
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next())
                System.out.println("Book Found: " + rs.getString("name"));
            else
                System.out.println("Book Not Found");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deletebook(int id) {
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                "DELETE FROM books WHERE id=?"
            );
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Book Deleted");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void issueBook(int bookId, String customer) {
        try (Connection con = DBConnection.getConnection()) {
            con.prepareStatement(
                "UPDATE books SET status='ISSUED' WHERE id=" + bookId
            ).executeUpdate();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO issued_books(book_id, customer_name, issue_date) VALUES (?,?,?)"
            );
            ps.setInt(1, bookId);
            ps.setString(2, customer);
            ps.setDate(3, Date.valueOf(LocalDate.now()));
            ps.executeUpdate();
            System.out.println("Book Issued");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void returnBook(int bookId) {
        try (Connection con = DBConnection.getConnection()) {
            con.prepareStatement(
                "UPDATE books SET status='AVAILABLE' WHERE id=" + bookId
            ).executeUpdate();

            con.prepareStatement(
                "DELETE FROM issued_books WHERE book_id=" + bookId
            ).executeUpdate();

            System.out.println("Book Returned");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void viewIssuedBooks() {
        try (Connection con = DBConnection.getConnection()) {
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM issued_books");
            while (rs.next()) {
                System.out.println(
                    rs.getInt("book_id") + " | " +
                    rs.getString("customer_name") + " | " +
                    rs.getDate("issue_date")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
