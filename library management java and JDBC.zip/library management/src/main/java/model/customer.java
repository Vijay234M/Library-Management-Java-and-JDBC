package model;

public class customer {
    private int customerId;
    private String customerName;



	public customer(int customerId, String customerName) {
        this.setCustomerId(customerId);
        this.customerName = customerName;
    }


	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
}



