package model;

public class staff {
    private int staffId;
    private String staffName;

    public staff(int staffId, String staffName) {
        this.setStaffId(staffId);
        this.staffName = staffName;
    }

    public String getStaffName() {
        return staffName;
    }

	public int getStaffId() {
		return staffId;
	}

	public void setStaffId(int staffId) {
		this.staffId = staffId;
	}
}
