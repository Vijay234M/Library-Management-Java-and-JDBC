package com.library.servlet;

import com.library.db.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class BookServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        try {
            Connection con = DBConnection.getConnection();

            if ("add".equals(action)) {
                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO books(name, author) VALUES (?, ?)"
                );
                ps.setString(1, req.getParameter("name"));
                ps.setString(2, req.getParameter("author"));
                ps.executeUpdate();
            }
            if ("update".equals(action)) {
                PreparedStatement ps = con.prepareStatement(
                    "UPDATE books SET name=?, author=? WHERE id=?"
                );
                ps.setString(1, req.getParameter("name"));
                ps.setString(2, req.getParameter("author"));
                ps.setInt(3, Integer.parseInt(req.getParameter("id")));
                ps.executeUpdate();
            }
            if ("delete".equals(action)) {
                PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM books WHERE id=?"
                );
                ps.setInt(1, Integer.parseInt(req.getParameter("id")));
                ps.executeUpdate();
            }



            res.sendRedirect("viewBooks.jsp");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
