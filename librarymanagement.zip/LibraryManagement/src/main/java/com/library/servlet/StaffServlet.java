package com.library.servlet;

import com.library.db.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class StaffServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        try {
            Connection con = DBConnection.getConnection();

            if ("add".equals(action)) {
                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO users(username,password,role) VALUES (?,?,?)"
                );
                ps.setString(1, req.getParameter("username"));
                ps.setString(2, req.getParameter("password"));
                ps.setString(3, "STAFF");
                ps.executeUpdate();
            }
            if ("delete".equals(action)) {
                PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM users WHERE id=?"
                );
                ps.setInt(1, Integer.parseInt(req.getParameter("id")));
                ps.executeUpdate();
            }
            if ("delete".equals(action)) {
                PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM users WHERE id=?"
                );
                ps.setInt(1, Integer.parseInt(req.getParameter("id")));
                ps.executeUpdate();
            }



            res.sendRedirect("viewStaff.jsp");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
