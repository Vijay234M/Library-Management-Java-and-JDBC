package com.library.servlet;

import com.library.db.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class CustomerServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        try {
            Connection con = DBConnection.getConnection();

            if ("add".equals(action)) {

                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO customers(name, password) VALUES (?, ?)"
                );
                ps.setString(1, req.getParameter("name"));
                ps.setString(2, req.getParameter("password"));
                ps.executeUpdate();

                res.sendRedirect("viewCustomer.jsp");
            }

            else if ("delete".equals(action)) {

                int id = Integer.parseInt(req.getParameter("id"));

                PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM customers WHERE id=?"
                );
                ps.setInt(1, id);
                ps.executeUpdate();

                res.sendRedirect("viewCustomer.jsp");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
