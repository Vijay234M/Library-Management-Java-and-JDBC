package com.library.servlet;

import com.library.db.DBConnection;


import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

public class IssueServlet extends HttpServlet {

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        response.setContentType("text/html");
        response.getWriter().println(
            "<h3>IssueServlet is running</h3>" +
            "<p>Please submit the Issue Book form.</p>"
        );
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        try {
            Connection con = DBConnection.getConnection();

            if ("issue".equals(action)) {

                int bookId = Integer.parseInt(request.getParameter("bookId"));
                String username = request.getParameter("username");

                PreparedStatement check = con.prepareStatement(
                    "SELECT status FROM books WHERE id=?"
                );
                check.setInt(1, bookId);
                ResultSet rs = check.executeQuery();

                if (rs.next() && "ISSUED".equals(rs.getString("status"))) {
                    response.getWriter().println("Book already issued!");
                    return;
                }

                PreparedStatement ps1 = con.prepareStatement(
                    "INSERT INTO issued_books (book_id, user, issue_date) VALUES (?, ?, ?)"
                );
                ps1.setInt(1, bookId);
                ps1.setString(2, username);
                ps1.setDate(3, java.sql.Date.valueOf(LocalDate.now()));
                ps1.executeUpdate();


                PreparedStatement ps2 = con.prepareStatement(
                    "UPDATE books SET status='ISSUED' WHERE id=?"
                );
                ps2.setInt(1, bookId);
                ps2.executeUpdate();

                response.sendRedirect("staff.jsp");
            }

           
            else if ("return".equals(action)) {

                int bookId = Integer.parseInt(request.getParameter("bookId"));

        
                PreparedStatement ps1 = con.prepareStatement(
                    "UPDATE books SET status='AVAILABLE' WHERE id=?"
                );
                ps1.setInt(1, bookId);
                ps1.executeUpdate();

           
                PreparedStatement ps2 = con.prepareStatement(
                    "DELETE FROM issued_books WHERE book_id=?"
                );
                ps2.setInt(1, bookId);
                ps2.executeUpdate();

                response.sendRedirect("customer.jsp");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
