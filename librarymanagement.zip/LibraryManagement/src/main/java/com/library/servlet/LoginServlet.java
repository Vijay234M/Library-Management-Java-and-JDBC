package com.library.servlet;

import com.library.db.DBConnection;
import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String u = req.getParameter("username");
        String p = req.getParameter("password");

        try {
            Connection con = DBConnection.getConnection();


            PreparedStatement ps = con.prepareStatement(
                "SELECT role FROM users WHERE username=? AND password=?"
            );
            ps.setString(1, u);
            ps.setString(2, p);

            ResultSet rs = ps.executeQuery();

            HttpSession session = req.getSession();

            if (rs.next()) {
                String role = rs.getString("role");
                session.setAttribute("user", u);
                session.setAttribute("role", role);

                if (role.equals("MANAGER")) {
                    res.sendRedirect("manager.jsp");
                } else if (role.equals("STAFF")) {
                    res.sendRedirect("staff.jsp");
                }
                return;
            }

           
            PreparedStatement ps2 = con.prepareStatement(
                "SELECT id, name FROM customers WHERE name=? AND password=?"
            );
            ps2.setString(1, u);
            ps2.setString(2, p);

            ResultSet rs2 = ps2.executeQuery();

            if (rs2.next()) {
                session.setAttribute("customerId", rs2.getInt("id"));
                session.setAttribute("customerName", rs2.getString("name"));
                session.setAttribute("role", "CUSTOMER");

                res.sendRedirect("customer.jsp");
            } else {
                res.getWriter().println("Invalid Username or Password");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
